<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\AuthenticationController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'userDetail']);
    Route::patch('/users/{id}', [UserController::class, 'updateUser']);
    Route::delete('/users/{id}', [UserController::class, 'deleteUser']);
    
    Route::get('/posts', [PostController::class, 'index']);
    Route::get('/posts/{id}', [PostController::class, 'postDetail']);
    Route::post('/posts', [PostController::class, 'createPost']);
    Route::patch('/posts/{id}', [PostController::class, 'updatePost']);
    Route::delete('/posts/{id}', [PostController::class, 'deletePost']);
    
    Route::get('/comments', [CommentController::class, 'index']);
    Route::get('/comments/{id}', [CommentController::class, 'commentDetail']);
    Route::post('/comments', [CommentController::class, 'createComment']);
    Route::patch('/comments/{id}', [CommentController::class, 'updateComment']);
    Route::delete('/comments/{id}', [CommentController::class, 'deleteComment']);
    
    Route::get('/logout', [AuthenticationController::class, 'logout']);
});

Route::post('/users', [UserController::class, 'createUser']);


Route::post('/login', [AuthenticationController::class, 'login']);