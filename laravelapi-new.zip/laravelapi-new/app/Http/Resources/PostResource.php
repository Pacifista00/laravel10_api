<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $commentData = null;

        if ($this->comment->isNotEmpty()) {
            $commentData = [];
            for($i=0 ; $i < count($this->comment) ; $i++){
                $newData = [
                    'comment_id' => $this->comment[$i]->id,
                    'user_id' => $this->comment[$i]->user_id,
                    'text' => $this->comment[$i]->text,
                    'created_at' => $this->comment[$i]->created_at,
                ];
                $commentData[] = $newData;
            };
            
        };
        
        return [
            'id' => $this->id,
            'user' => $this->user->username,
            'description' => $this->description,
            'comment' => $commentData
        ];
    }
}
