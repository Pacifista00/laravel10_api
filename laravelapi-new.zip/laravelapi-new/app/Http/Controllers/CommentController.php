<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use App\Http\Resources\CommentResource;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;


class CommentController extends Controller
{
    public function index(){
        $data = Comment::all();
        return CommentResource::collection($data);
    }
    public function commentDetail($id){
        $comment = Comment::find($id);

        if(!$comment){
            return response()->json(['message' => 'Post not found'], 404);
        }

        $data = Comment::find($id);
        return new CommentResource($data);
    }
    public function createComment(Request $request){

        $request->validate([
            'text' => 'required|max:254',
        ]);

        Comment::create([
            'user_id' => Auth::user()->id,
            'post_id' => $request->post_id,
            'text' => $request->text,
        ]);
    }
    public function updateComment(Request $request, $id){

        $request->validate([
            'text' => 'required|max:254',
        ]);

        $comment = Comment::find($id);

        if (!$comment) {
            return response()->json(['message' => 'Comment not found'], 404);
        }

        if($comment->user_id != Auth::user()->id){
            return response()->json(['message' => 'Comment not found'], 404);
        }else{
            Comment::find($id)->update([
                'text' => $request->text,
            ]);
        };
    }
    public function deleteComment($id){
        $comment = comment::find($id);

        if (!$comment) {
            return response()->json(['message' => 'Post not found'], 404);
        }

        if($comment->id != Auth::user()->id){
            return response()->json(['message' => 'User not found'], 404);
        }else{
            $comment->delete();
        };
    }
}
